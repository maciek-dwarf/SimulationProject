#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Projectile.h"
#include "Ball.generated.h"



UENUM(BlueprintType)
enum class EBallColor : uint8
{
    RED     UMETA(DisplayName = "Red"),
    BLUE    UMETA(DisplayName = "Blue")
};

UENUM(BlueprintType)
enum class EBallState : uint8
{
    MOVING   UMETA(DisplayName = "MOVING"),
    FIGHTING UMETA(DisplayName = "FIGHTING"),
    IDLE     UMETA(DisplayName = "IDLE"),
    DYING     UMETA(DisplayName = "DYING")
};

UCLASS()
class ILLUVIUMTEST_API ABall : public AActor
{
    GENERATED_BODY()

public:
    // Sets default values for this actor's properties
    ABall();

protected:
    // Called when the game starts or when spawned
    virtual void BeginPlay() override;

public:
    // Called every frame
    virtual void Tick(float DeltaTime) override;

    // Hitpoints for the ball
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    int32 HitPoints;

    // Hitpoints for the ball
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    int32 MaxHitPoints;

    // Radius of the ball
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    float Radius;

    // Speed of the ball (nr of cell moved in one Time interval)
    // I assume it's small for example 1 cell in 5 time intervals
    // otherwise it would be too fast
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    float Speed = 0.2f;

    // Starting position of the ball
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    FVector StartPos;

    // Position of the ball we move to
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    FVector EndPos;

    //nr of time intervals to shoot
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    float ShootingRate = 20;

    //nr of time intervals without shooting 
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    float NotShoot = 0;

    //time ball is moving betwen cells
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    float Time = 0.0f;

    UFUNCTION(BlueprintCallable)
    void OnHit();

    UFUNCTION(BlueprintCallable)
    void FireProjectile();

    // Projectile class reference to spawn
    UPROPERTY(EditAnywhere, Category = "Shooting")
    TSubclassOf<AProjectile> ProjectileClass;

    // Target ball pointer
    TWeakObjectPtr<ABall> TargetBall;

    // Function to set target ball
    void SetTargetBall(ABall* NewTarget);

    // Function to check TargetBall validity
    bool IsTargetBallValid() const;


    // Ball color
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    EBallColor BallColor;

    // Ball State
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    EBallState BallState;

    
    float dying_timer = 0.f;
    
    // Dynamic material instance reference
    class UMaterialInstanceDynamic* DynamicMaterialInstance;

public:
    // Getter for HitPoints
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    int32 GetHitPoints() const;

    // Setter for HitPoints
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    void SetHitPoints(int32 NewHitPoints);

    // Getter for BallColor
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    EBallColor GetBallColor() const;

    // Setter for BallColor
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    void SetBallColor(EBallColor NewColor);

    // Getter for Radius
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    float GetRadius() const;

    // Setter for Radius
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    void SetRadius(float NewRadius);

    // Getter for BallState
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    EBallState GetBallState() const;

    // Setter for BallState
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    void SetBallState(EBallState NewState);

    // Getter for EndPos
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    FVector GetEndPos() const;

    // Setter for EndPos
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    void SetEndPos(const FVector& NewEndPos);

    // Getter for StartPos
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    FVector GetStartPos() const;

    // Setter for StartPos
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    void SetStartPos(const FVector& NewStartPos);

    // Getter for Speed
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    float GetSpeed() const;

    // Setter for Speed
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    void SetSpeed(float NewSpeed);

    // Getter for Time
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    float GetTime() const;

    // Setter for Time
    UFUNCTION(BlueprintCallable, Category = "Ball Properties")
    void SetTime(float NewTime);

private:
    // Sphere component
    UPROPERTY(VisibleAnywhere)
    class UStaticMeshComponent* BallComponent;

    void UpdateBallColor();
    void SetDynamicMaterial();
};
// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GridSimulation.generated.h"

struct FCoordinatePair
{
    int32 X;

    int32 Y;

    FCoordinatePair() : X(0), Y(0) {}
    FCoordinatePair(int32 InX, int32 InY) : X(InX), Y(InY) {}

    // Equality operator
    bool operator==(const FCoordinatePair& Other) const
    {
        return X == Other.X && Y == Other.Y;
    }
};

static uint32 GetTypeHash(const FCoordinatePair& Pair)
{
    return HashCombine(GetTypeHash(Pair.X), GetTypeHash(Pair.Y));
};


UCLASS()
class ILLUVIUMTEST_API AGridSimulation : public AActor
{
	GENERATED_BODY()
	
public:
    AGridSimulation();

protected:
    virtual void BeginPlay() override;    

public:
    virtual void Tick(float DeltaTime) override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    int32 Rows = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    int32 Columns = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    int32 NumberOfRedBalls = 1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    int32 RedBallSeed = 1232;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    int32 NumberOfBlueBalls = 1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    int32 BlueBallSeed = 101;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    float TileSize = 100.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    float TimeStamp = 0.1f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    float DistanceToShoot = 5.0f;

    UFUNCTION(BlueprintCallable)
    void CreateGrid();

    UFUNCTION(BlueprintCallable)
    void CreateBalls();

        
    // Array to hold ABall (red) instances , accessible in editor for debugging purpose
    //UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    TArray<TWeakObjectPtr<class ABall>> RedBalls;

    // Array to hold ABall (blue) instances , accessible in editor for debugging purpose
    //UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
    TArray<TWeakObjectPtr<class ABall>> BlueBalls;

    // Speed of the ball (nr of cell moved in one Time interval)
    // I assume it's small for example 1 cell in 5 time intervals
    // otherwise it would be too fast
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ball Properties")
    float Speed = 0.2f;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    class UProceduralMeshComponent* ProceduralMeshComponent;

    TSet< FCoordinatePair> OccupiedCells;

    // computin grid coordinates based on worldposition
    UFUNCTION()
    FVector2D ComputeGridCoordinates(const FVector& WorldPosition) const;

    // checking if coordinates are valid in the grid
    UFUNCTION()
    bool IsValidGridCoordinates(const float X, const float Y) const;

    // Timer handle
    FTimerHandle TimerHandle;

    // Function to be called at each interval
    UFUNCTION()
    void UpdateSimulation();

    void UpdateGridFreeCellsInfo();

    void RemoveDeadballs();

    void UpdateBalls(TArray<TWeakObjectPtr<ABall>>& Balls, TArray<TWeakObjectPtr<ABall>>& OpositeBalls);

    // Finding closest ball from array Balls to Ball
    ABall* FindClosestBall(TWeakObjectPtr<class ABall>& Ball, TArray<TWeakObjectPtr<class ABall>>& Balls);

    FVector ComputeClosestNeighbourToTarget(const FVector& WorldPosition, 
        const FVector& WorldPositionTarget) const;

    FVector ComputeWorldPositionFromGrid(int32 GridX, int32 GridY) const;

    FRandomStream RandomStreamForRed;
    FRandomStream RandomStreamForBlue;

    
};

#include "Ball.h"
#include "Components/SphereComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Components/StaticMeshComponent.h"

// Sets default values
ABall::ABall()
{
    PrimaryActorTick.bCanEverTick = true;
    // Create the sphere component and set it as the root component
    BallComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BallComponent"));
    RootComponent = BallComponent;

    // Load the spherical mesh from the Engine assets
    static ConstructorHelpers::FObjectFinder<UStaticMesh> BallComponentAsset(TEXT("StaticMesh'/Engine/BasicShapes/Sphere.Sphere'"));

    if (BallComponentAsset.Succeeded())
    {
        // Set the spherical mesh to the static mesh component
        BallComponent->SetStaticMesh(BallComponentAsset.Object);
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("ABall : Spherical mesh not found!"));
    }

    
    // Set default values for the ball's properties
    HitPoints = 100;  // Example default value
    BallColor = EBallColor::RED;  // Default color
    BallState = EBallState::IDLE; //Default state

    // Initialize the sphere shape, define physics properties, scale, and collision settings
    //BallComponent->SetWorldScale3D(FVector(2.0f, 2.0f, 2.0f));  // Scale the sphere to appear larger
    BallComponent->SetSimulatePhysics(true);  // Enable physics simulation
    BallComponent->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);  // Enable collision

    // Assign the material
    ConstructorHelpers::FObjectFinder<UMaterial> MaterialAsset(TEXT("/Game/Materials/MBall"));
    if (MaterialAsset.Succeeded())
    {
        // Create a dynamic instance of the material for runtime modifications
        DynamicMaterialInstance = UMaterialInstanceDynamic::Create(MaterialAsset.Object, this, FName(TEXT("Base Material Dynamic")));

        if (DynamicMaterialInstance)
        {
            DynamicMaterialInstance->SetFlags(RF_Transient);  // Set transient flag for dynamic materials
        }
    }
    else
    {
        DynamicMaterialInstance = nullptr;
        UE_LOG(LogTemp, Warning, TEXT("ABall : Material not found!"));
    }
}

// Called when the game starts or when spawned
void ABall::BeginPlay()
{
    Super::BeginPlay();  // Call the base class BeginPlay

    SetDynamicMaterial();  // Set the dynamic material on the ball
    UpdateBallColor();     // Update the color based on the enum value
}

void ABall::SetDynamicMaterial()
{
    if (DynamicMaterialInstance)
    {
        // Create a dynamic instance of the material        
        BallComponent->SetMaterial(0, DynamicMaterialInstance);
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("SetDynamicMaterial : Material not found!"));
    }

}

const float TimeOfDying = 2.7f;

// Called every frame
void ABall::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
    Time += DeltaTime;
    switch (BallState) 
    {
    case EBallState::IDLE:
        Time = 0.0f;
        break;
    case EBallState::MOVING:
    {        
        FVector2D DistanceVec((EndPos - StartPos).X, (EndPos - StartPos).Y);
        //DistanceVec.Normalize();
        FVector2D DistanceDT = DistanceVec * Speed * DeltaTime;
        FVector NewPosition = FVector(DistanceDT.X, DistanceDT.Y, 0.f)
            + GetActorLocation();
        //UE_LOG(LogTemp, Warning, TEXT("NewPosition %s"), *NewPosition.ToString());
        //UE_LOG(LogTemp, Warning, TEXT("NewPosition"));
        SetActorLocation(NewPosition);
        break;
    }
     
    case EBallState::FIGHTING:
        break;

    case EBallState::DYING:
        dying_timer += DeltaTime;
        if (dying_timer > TimeOfDying)
        {
            Destroy();
        }
    }
}

void ABall::UpdateBallColor()
{    
    if (DynamicMaterialInstance)
    {
        if (BallState == EBallState::FIGHTING)
        {
            float ColorDt = (float)HitPoints / (float)MaxHitPoints;
            if (BallColor == EBallColor::RED)
            {                
                FLinearColor Color(0.4f + ColorDt * 0.5f, 0.1f + ColorDt * 0.5f, 0.1f + ColorDt * 0.5f, 1.0f);
                DynamicMaterialInstance->SetVectorParameterValue(FName("BaseColor"), Color);
            }
            else if (BallColor == EBallColor::BLUE)
            {                
                FLinearColor Color(0.1f+ ColorDt*0.5f, 0.1f + ColorDt * 0.5f, 0.4f + ColorDt * 0.5f, 1.0f);
                DynamicMaterialInstance->SetVectorParameterValue(FName("BaseColor"), Color);                
            }
        }
        else if(BallState == EBallState::IDLE || BallState == EBallState::MOVING) {
                      
            if (BallColor == EBallColor::RED)
            {                
                DynamicMaterialInstance->SetVectorParameterValue(FName("BaseColor"), FLinearColor::Red);
            }
            else if (BallColor == EBallColor::BLUE)
            {
                DynamicMaterialInstance->SetVectorParameterValue(FName("BaseColor"), FLinearColor::Blue);
            }
        } 
        else //if (BallState == DYING) 
        {
            
            float R = FMath::RandRange(0.0f, 1.0f);
            float G = FMath::RandRange(0.0f, 1.0f);
            float B = FMath::RandRange(0.0f, 1.0f);

            if (BallColor == EBallColor::RED)
            {
                FLinearColor Color(1.f, G, B);
                DynamicMaterialInstance->SetVectorParameterValue(FName("BaseColor"), Color);
            }
            else if (BallColor == EBallColor::BLUE)
            {
                FLinearColor Color(R, G, 1.0f);
                DynamicMaterialInstance->SetVectorParameterValue(FName("BaseColor"), Color);
            }                        
        }
    }
    else
    {        
        UE_LOG(LogTemp, Warning, TEXT("UpdateBallColor :: DynamicMaterialInstance not found!"));
    }
}

// Getter for HitPoints
int32 ABall::GetHitPoints() const
{
    return HitPoints;
}

// Setter for HitPoints
void ABall::SetHitPoints(int32 NewHitPoints)
{
    //we set hitpoints only once so we can do it
    MaxHitPoints = NewHitPoints;
    HitPoints = NewHitPoints;
}

// Getter for BallColor
EBallColor ABall::GetBallColor() const
{
    return BallColor;
}

// Setter for BallColor
void ABall::SetBallColor(EBallColor NewColor)
{
    BallColor = NewColor;
    UpdateBallColor(); // Call to update material color based on the new ball color
}

// Getter for Radius
float ABall::GetRadius() const
{
    return Radius;
}

// Setter for Radius
void ABall::SetRadius(float NewRadius)
{
    Radius = NewRadius;    
    BallComponent->SetWorldScale3D(FVector(NewRadius /50.0f)); // Assuming original sphere radius is 50
}

// Getter for BallState
EBallState ABall::GetBallState() const
{
    return BallState;
}

// Setter for BallState
void ABall::SetBallState(EBallState NewState)
{    
    BallState = NewState;    
}

void ABall::SetTargetBall(ABall* NewTarget)
{
    if (NewTarget)
    {
        TargetBall = NewTarget;
    }
    else
    {
        TargetBall.Reset(); // Reset if the new target is nullptr
    }
}

bool ABall::IsTargetBallValid() const
{
    return TargetBall.IsValid();
}

// Getter for StartPos
FVector ABall::GetStartPos() const
{
    return StartPos; // Return the current value of StartPos
}

// Setter for StartPos
void ABall::SetStartPos(const FVector& NewStartPos)
{
    StartPos = NewStartPos; // Set the new value
}

// Getter for EndPos
FVector ABall::GetEndPos() const
{
    return EndPos; // Return the current value of EndPos
}

// Setter for EndPos
void ABall::SetEndPos(const FVector& NewEndPos)
{
    EndPos = NewEndPos; // Set the new value
}

// Getter for Speed
float ABall::GetSpeed() const
{
    return Speed; // Return the current value of Speed
}

// Setter for Speed
void ABall::SetSpeed(float NewSpeed)
{
    if (NewSpeed >= 0.0f) // Adding a validation check (speed should not be negative)
    {
        Speed = NewSpeed; // Set the new value
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("Speed must be non-negative.")); // Log a warning if invalid
    }
}

// Getter for Time
float ABall::GetTime() const
{
    return Time; // Return the current value of Time
}

// Setter for Time
void ABall::SetTime(float NewTime)
{
    if (NewTime >= 0.0f) // Validation to ensure time is non-negative
    {
        Time = NewTime; // Set the new value
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("Time must be non-negative.")); // Log a warning if invalid
    }
}

void ABall::OnHit()
{
    // Handling logic when this object is hit
    UE_LOG(LogTemp, Warning, TEXT("ABall hit!"));
    HitPoints--;
    if (HitPoints <= 0)
    {
        HitPoints = 0;
        BallState = EBallState::DYING;
    }
        
    
}

void ABall::FireProjectile()
{
    if (TargetBall.IsValid())
    {
        FVector Start = GetActorLocation(); // Spawn at this ball's location
        FVector End = TargetBall->GetActorLocation()+FVector(15.f,15.f, 15.f);
        FColor LineColor = BallColor == EBallColor::BLUE ? FColor::Blue : FColor::Red;
        DrawDebugLine(
            GetWorld(),         // World context
            Start,              // Start point
            End,                // End point
            LineColor,          // Line color
            false,              // Persistent line (false means it will only appear for a single frame)
            1.0f,               // How long to draw the line (if persistent, in seconds)
            0,                  // Depth priority
            5.0f                // Thickness of the line
        );
        TargetBall->OnHit();
      //  DrawDebugSphere(GetWorld(), SpawnLocation, 500.0f, 10.0f, FColor::Green, true, -1.0f, 10.0f);
      

        
    }
}
// Fill out your copyright notice in the Description page of Project Settings.
#include "GridSimulation.h"
#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "Ball.h"

#include "ProceduralMeshComponent.h"

#include <cfloat> 

// Sets default values
AGridSimulation::AGridSimulation()
{
    PrimaryActorTick.bCanEverTick = false; // Disable default tick if you want custom control

    // Create and initialize the procedural mesh component
    ProceduralMeshComponent = CreateDefaultSubobject<UProceduralMeshComponent>(TEXT("ProceduralMesh"));
    RootComponent = ProceduralMeshComponent;

    ConstructorHelpers::FObjectFinder<UMaterial> MaterialAsset(TEXT("/Game/Materials/MGrid"));
    if (MaterialAsset.Succeeded())
    {
        ProceduralMeshComponent->SetMaterial(0, MaterialAsset.Object);
    }
    else
    {     
        UE_LOG(LogTemp, Warning, TEXT("AGridSimulation:Material not found!"));
    }
}

void AGridSimulation::UpdateBalls(TArray<TWeakObjectPtr<ABall>>& Balls, TArray<TWeakObjectPtr<ABall>>& OpositeBalls)
{
    for (auto& ball : Balls)
    {
        ball->SetBallColor(ball->BallColor);
        //auto RedBall = RedBalls[index1];
        if (ball->GetBallState() == EBallState::IDLE)
        {
            FVector2D GridCoord = ComputeGridCoordinates(ball->GetActorLocation() - GetActorLocation());
            ABall* ClosestBall = FindClosestBall(ball, OpositeBalls);
            if (ClosestBall&& ClosestBall->GetBallState()!= EBallState::DYING)
            {
                FVector2D ClosestGridCoord = ComputeGridCoordinates(ClosestBall->GetActorLocation() - GetActorLocation());
                FVector2D DiffCoord = ClosestGridCoord - GridCoord;
                if (DiffCoord.Length() < DistanceToShoot)
                {
                    ball->SetBallState(EBallState::FIGHTING);
                    ball->SetTargetBall(ClosestBall);
                } 
                else {
                    FVector TargetNeighbour = ComputeClosestNeighbourToTarget(ball->GetActorLocation(),
                        ClosestBall->GetActorLocation());
                    ball->SetEndPos(TargetNeighbour);
                    ball->SetStartPos(ball->GetActorLocation());
                    ball->SetBallState(EBallState::MOVING);

                    ball->SetSpeed(Speed / TimeStamp);
                }
            }

        }
        else if (ball->GetBallState() == EBallState::MOVING)
        {
            FVector DistToTarget = ball->GetEndPos() - ball->GetActorLocation();
            if (ball->GetTime() > TimeStamp / Speed)
            {
                ball->SetTime(0.0f);
                FVector2D GridCoord = ComputeGridCoordinates(ball->GetActorLocation() - GetActorLocation());
                ABall* ClosestBall = FindClosestBall(ball, OpositeBalls);
                if (ClosestBall && ClosestBall->GetBallState() != EBallState::DYING)
                {
                    FVector2D ClosestGridCoord = ComputeGridCoordinates(ClosestBall->GetActorLocation() - GetActorLocation());
                    FVector2D DiffCoord = ClosestGridCoord - GridCoord;
                    if (DiffCoord.Length() < DistanceToShoot)
                    {
                        ball->SetBallState(EBallState::FIGHTING);
                        ball->SetTargetBall(ClosestBall);
                    }
                    else {
                        FVector TargetNeighbour = ComputeClosestNeighbourToTarget(ball->GetActorLocation(),
                            ClosestBall->GetActorLocation());
                        ball->SetEndPos(TargetNeighbour);
                        ball->SetStartPos(ball->GetActorLocation());
                        ball->SetBallState(EBallState::MOVING);

                        ball->SetSpeed(Speed / TimeStamp);
                    }
                }
                else {
                    
                }
            }
        }
        else //if (ball->GetBallState() == EBallState::FIGHTING)
        {
            if (!ball->TargetBall.IsValid() || ball->TargetBall->GetBallState() == EBallState::DYING)
            {
                ball->SetBallState(EBallState::IDLE);
            }
            else
            {
                if (ball->NotShoot == ball->ShootingRate)
                {
                    ball->NotShoot = 0;
                    ball->FireProjectile();
                } 
                else // if ball->NotShoot < ball->ShootingRate
                {
                    ball->NotShoot += 1;                        
                }
            }
        }
    }

}

void AGridSimulation::RemoveDeadballs()
{
    TArray<TWeakObjectPtr<ABall>> NewRedBalls;
    for (auto& ball : RedBalls)
    {
        if (ball.IsValid())
        {
            NewRedBalls.Add(ball);
        }
    }
    RedBalls = NewRedBalls;

    TArray<TWeakObjectPtr<ABall>> NewBlueBalls;
    for (auto& ball : BlueBalls)
    {
        if (ball.IsValid())
        {
            NewBlueBalls.Add(ball);
        }
    }
    BlueBalls = NewBlueBalls;

}

void AGridSimulation::UpdateSimulation()
{
    
    //Getting rid of dead balls
    //keep only alive balls
    RemoveDeadballs();
    UpdateGridFreeCellsInfo();
    //handling red balls
    AGridSimulation::UpdateBalls(RedBalls, BlueBalls);

    RemoveDeadballs();

    //handling blue balls
    AGridSimulation::UpdateBalls(BlueBalls, RedBalls);    
}

void AGridSimulation::UpdateGridFreeCellsInfo()
{
    TSet<FCoordinatePair> TempSet;
    for (auto& ball : RedBalls)
    {
        FVector2D GridCoord = ComputeGridCoordinates(ball->GetActorLocation() - GetActorLocation());    
        FCoordinatePair pair(GridCoord.X, GridCoord.Y);
        TempSet.Add(pair);
    }

    for (auto& ball : BlueBalls)
    {
        FVector2D GridCoord = ComputeGridCoordinates(ball->GetActorLocation() - GetActorLocation());
        FCoordinatePair pair(GridCoord.X, GridCoord.Y);
        TempSet.Add(pair);
    }

    OccupiedCells = TempSet;
}

ABall* AGridSimulation::FindClosestBall(TWeakObjectPtr<ABall>& Ball, TArray<TWeakObjectPtr<ABall>>& Balls)
{
    float ClosestBallLength = FLT_MAX;
    ABall* ans = nullptr;
    for (auto b : Balls)
    {
        FVector DiffPosition = b->GetActorLocation() -  Ball->GetActorLocation();
        if (DiffPosition.Length() < ClosestBallLength)
        {
            ans = b.Get();
            ClosestBallLength = DiffPosition.Length();
        }
    }
    return ans;
}

void AGridSimulation::BeginPlay()
{
    Super::BeginPlay();
    CreateGrid(); // Call function to create the grid
    CreateBalls(); // Create red and blue balls
    GetWorld()->GetTimerManager().SetTimer(TimerHandle, this, &AGridSimulation::UpdateSimulation, 
        TimeStamp, true);
}

void AGridSimulation::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

void AGridSimulation::CreateBalls()
{
    FVector Origin = GetActorLocation();
    // Calculate effective scales
    FVector Scale = GetActorScale3D();
    float SizeX = TileSize * Scale.X;
    float SizeY = TileSize * Scale.Y;
    // Initialize the random stream with the given seed
    RandomStreamForRed.Initialize(RedBallSeed);
    RandomStreamForBlue.Initialize(BlueBallSeed);
    
    // Generate random row and column indices    
    for (int32 index = 0; index < NumberOfRedBalls; ++index)
    {
        int32 RandomRow = RandomStreamForRed.RandRange(0, Rows - 1);
        int32 RandomColumn = RandomStreamForRed.RandRange(0, Columns - 1);
        int32 HitPoints = RandomStreamForRed.RandRange(2, 5);
        float Radius = FMath::FRandRange(SizeX * 0.15f, SizeX * 0.22f);
        FVector Position;
        Position.X = SizeX * RandomRow + SizeX * 0.5f;
        Position.Y = SizeY * RandomColumn + SizeY * 0.5f;
        Position.Z = Radius+3.0f;
        Position += Origin;
        ABall* ball = GetWorld()->SpawnActor<ABall>(ABall::StaticClass(), Position, FRotator::ZeroRotator);
        ball->SetHitPoints(HitPoints);
        ball->SetRadius(Radius);
        ball->SetBallColor(EBallColor::RED);
        RedBalls.Add(ball);
    }

    for (int32 index = 0; index < NumberOfBlueBalls; ++index)
    {
        int32 RandomRow = RandomStreamForBlue.RandRange(0, Rows - 1);
        int32 RandomColumn = RandomStreamForBlue.RandRange(0, Columns - 1);
        int32 HitPoints = RandomStreamForBlue.RandRange(2, 5);
        float Radius = FMath::FRandRange(SizeX * 0.15f, SizeX * 0.22f);
        FVector Position;
        Position.X = SizeX * RandomRow + SizeX * 0.5f;
        Position.Y = SizeY * RandomColumn + SizeY * 0.5f;
        Position.Z = Radius + 3.0f;
        Position += Origin;
        ABall* ball = GetWorld()->SpawnActor<ABall>(ABall::StaticClass(), Position, FRotator::ZeroRotator);
        ball->SetHitPoints(HitPoints);
        ball->SetRadius(Radius);
        ball->SetBallColor(EBallColor::BLUE);
        BlueBalls.Add(ball);
    }
}

void AGridSimulation::CreateGrid()
{    
    TArray<FVector> Vertices;
    TArray<int32> Triangles;
    TArray<FColor> VertexColors;
    TArray<FVector> Normals;
    TArray<FVector2D> UVs;

    FVector Origin = GetActorLocation();

    // Calculate effective scales
    FVector Scale = GetActorScale3D();

    for (int32 Row = 0; Row < Rows; Row++)
    {
        for (int32 Column = 0; Column < Columns; Column++)
        {
                        
            FVector BottomLeft = FVector(Column * TileSize * Scale.X, Row * TileSize * Scale.Y, 0)/* + Origin*/;
            FVector BottomRight = BottomLeft + FVector(TileSize * Scale.X, 0, 0);
            FVector TopLeft = BottomLeft + FVector(0, TileSize * Scale.Y, 0);
            FVector TopRight = BottomRight + FVector(0, TileSize * Scale.Y, 0);

            // Add vertices for two triangles
            int32 VertexIndex = Vertices.Num();
            Vertices.Add(BottomLeft);
            Vertices.Add(BottomRight);
            Vertices.Add(TopLeft);
            Vertices.Add(TopRight);

            // Create two triangles for the square
            Triangles.Add(VertexIndex + 0);
            Triangles.Add(VertexIndex + 2);
            Triangles.Add(VertexIndex + 1);

            Triangles.Add(VertexIndex + 1);
            Triangles.Add(VertexIndex + 2);
            Triangles.Add(VertexIndex + 3);


            // Assign colors (alternating)
            FColor TileColor = (Row + Column) % 2 == 0 ? FColor::White : FColor::Black;
            VertexColors.Add(TileColor);
            VertexColors.Add(TileColor);
            VertexColors.Add(TileColor);
            VertexColors.Add(TileColor);
            
        }
    }
    ProceduralMeshComponent->CreateMeshSection(0, Vertices, Triangles, Normals, UVs, VertexColors, TArray<FProcMeshTangent>(), true);
    
}

bool AGridSimulation::IsValidGridCoordinates(const float X, const float Y) const
{
    if (X < 0 || X >= Rows)
        return false;
    if (Y < 0 || Y >= Columns)
        return false;
    return true;
}

FVector2D AGridSimulation::ComputeGridCoordinates(const FVector& WorldPosition) const
{    
    // Calculate effective scales
    FVector Scale = GetActorScale3D();
    float SizeX = TileSize * Scale.X;
    float SizeY = TileSize * Scale.Y;
    // Compute the X and Y grid indices
    int32 GridX = static_cast<int32>(FMath::Floor(WorldPosition.X / SizeX));
    int32 GridY = static_cast<int32>(FMath::Floor(WorldPosition.Y / SizeY));

    // Return the grid coordinates as a FVector2D
    return FVector2D(GridX, GridY);
}

FVector AGridSimulation::ComputeWorldPositionFromGrid(int32 GridX, int32 GridY) const
{
    // Calculate effective scales
    FVector Scale = GetActorScale3D();
    float SizeX = TileSize * Scale.X;
    float SizeY = TileSize * Scale.Y;
    // Compute the world position based on grid coordinates and tile size
    float WorldX = GridX * SizeX + SizeX * 0.5f; // Calculate world position X
    float WorldY = GridY * SizeY + SizeY * 0.5f; // Calculate world position Y
    float WorldZ = 0.0f; // Assuming a flat grid, set Z to 0 (or however you'd like to set it)

    return FVector(WorldX, WorldY, WorldZ) + GetActorLocation(); // Return the computed world position
}

FVector AGridSimulation::ComputeClosestNeighbourToTarget(const FVector& WorldPosition, 
    const FVector& WorldPositionTarget) const
{
    FVector2D GridCoord = ComputeGridCoordinates(WorldPosition - GetActorLocation());    
    FVector2D TargetsGridCoord = ComputeGridCoordinates(WorldPositionTarget - GetActorLocation());
    TArray<FVector2D> NeighbourDiff{ FVector2D{0,1}, FVector2D{0,-1}, 
        FVector2D{1,1}, FVector2D{1,-1}, FVector2D{1,0}, 
        FVector2D{-1,1}, FVector2D{-1,-1}, FVector2D{-1,0} };
    FVector2D CurrentClosestGridCoord;
    float CurrMinDistance = FLT_MAX;
    for (auto& Diff : NeighbourDiff)
    {
        FVector2D Candidate = Diff + GridCoord;
        if (IsValidGridCoordinates(Candidate.X, Candidate.Y))
        {
                        
            if (!OccupiedCells.Contains(FCoordinatePair(Candidate.X, Candidate.Y)))
            {
                float length = (TargetsGridCoord - Candidate).Length();
                if (length < CurrMinDistance)
                {
                    CurrMinDistance = length;
                    CurrentClosestGridCoord = Candidate;
                }
            }
        }
    }
    return ComputeWorldPositionFromGrid(CurrentClosestGridCoord.X, CurrentClosestGridCoord.Y);
}
